The `contrib` directory contains documents, scripts, and other helpful things which are contributed by the community.
