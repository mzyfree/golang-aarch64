#!/bin/sh
sudo -E -u \#10000 "/harbor/harbor_core"

